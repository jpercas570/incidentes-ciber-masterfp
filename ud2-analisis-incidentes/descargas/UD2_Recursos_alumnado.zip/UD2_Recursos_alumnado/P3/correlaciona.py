#!/usr/bin/env python3
"""Correlación físico-lógica para la práctica P3 de la UD2 (ACME Logística).

Cruza las entradas al CPD fuera de horario (control de accesos, JSON por líneas)
con los inicios de sesión SSH correctos (auth.log de los servidores) del mismo
usuario en los segundos siguientes. Hace lo mismo que la regla 100320 de Wazuh
del módulo 3, pero sobre ficheros, para poder probarlo sin SIEM.

Uso:
    python3 correlaciona.py --pacs pacs_eventos.json --auth auth_srv-bd01.log auth_srv-web01.log
"""
import argparse
import json
import re
from datetime import datetime, timedelta, timezone

MESES = {"Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6,
         "Jul": 7, "Aug": 8, "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12}
LINEA_SSH = re.compile(
    r"^(?P<mes>\w{3})\s+(?P<dia>\d{1,2}) (?P<hora>\d\d:\d\d:\d\d) (?P<equipo>\S+) "
    r"sshd\[\d+\]: Accepted (?P<metodo>\S+) for (?P<usuario>\S+) from (?P<ip>\S+) port \d+")
HORA_LOCAL = timezone(timedelta(hours=1))  # hora peninsular de invierno


def fuera_de_horario(momento, inicio, fin):
    """True si la hora cae entre 'inicio' (p. ej. 20) y 'fin' (p. ej. 7)."""
    return momento.hour >= inicio or momento.hour < fin


def leer_pacs(ruta, zona, inicio, fin):
    entradas = []
    with open(ruta, encoding="utf-8") as fichero:
        for numero, linea in enumerate(fichero, 1):
            if not linea.strip():
                continue
            evento = json.loads(linea)
            momento = datetime.fromisoformat(evento["timestamp"])
            datos = evento["pacs"]
            if (datos["evento"] == "acceso_concedido" and datos["zona"] == zona
                    and fuera_de_horario(momento, inicio, fin)):
                entradas.append({"momento": momento, "usuario": evento.get("dstuser", "?"),
                                 "titular": datos.get("titular", "?"), "puerta": datos["puerta"],
                                 "tarjeta": datos.get("tarjeta", "?")})
    return entradas


def leer_auth(rutas, anio):
    sesiones = []
    for ruta in rutas:
        with open(ruta, encoding="utf-8") as fichero:
            for linea in fichero:
                m = LINEA_SSH.match(linea)
                if not m:
                    continue
                h, mi, s = (int(x) for x in m["hora"].split(":"))
                momento = datetime(anio, MESES[m["mes"]], int(m["dia"]), h, mi, s, tzinfo=HORA_LOCAL)
                sesiones.append({"momento": momento, "usuario": m["usuario"], "equipo": m["equipo"],
                                 "ip": m["ip"], "metodo": m["metodo"]})
    return sesiones


def main():
    p = argparse.ArgumentParser(description="Correlación de entradas al CPD y sesiones SSH")
    p.add_argument("--pacs", required=True, help="eventos del control de accesos (JSON por líneas)")
    p.add_argument("--auth", required=True, nargs="+", help="uno o varios auth.log")
    p.add_argument("--anio", type=int, default=2026, help="año de las líneas de syslog (no lo incluyen)")
    p.add_argument("--ventana", type=int, default=600, help="segundos tras la entrada (600 = 10 min)")
    p.add_argument("--inicio", type=int, default=20, help="hora a partir de la que es fuera de horario")
    p.add_argument("--fin", type=int, default=7, help="hora hasta la que es fuera de horario")
    p.add_argument("--zona", default="CPD")
    a = p.parse_args()

    entradas = leer_pacs(a.pacs, a.zona, a.inicio, a.fin)
    sesiones = leer_auth(a.auth, a.anio)
    print(f"Entradas a la zona {a.zona} fuera de horario ({a.inicio}:00-{a.fin}:00): {len(entradas)}")
    print(f"Inicios de sesión SSH correctos leídos: {len(sesiones)}\n")

    sin_sesion = []
    for e in entradas:
        limite = e["momento"] + timedelta(seconds=a.ventana)
        coinciden = [s for s in sesiones
                     if s["usuario"] == e["usuario"] and e["momento"] <= s["momento"] <= limite]
        if not coinciden:
            sin_sesion.append(e)
            continue
        for s in coinciden:
            segundos = int((s["momento"] - e["momento"]).total_seconds())
            print(f"CORRELACIÓN  {e['momento']:%Y-%m-%d %H:%M:%S}  {e['puerta']}  "
                  f"{e['usuario']} ({e['titular']}, tarjeta {e['tarjeta']})")
            print(f"             -> {s['momento']:%H:%M:%S} {s['equipo']}: Accepted {s['metodo']} "
                  f"desde {s['ip']} (+{segundos} s)\n")
    for e in sin_sesion:
        print(f"Sin sesión posterior: {e['momento']:%Y-%m-%d %H:%M:%S} {e['puerta']} "
              f"{e['usuario']} ({e['titular']})")


if __name__ == "__main__":
    main()
