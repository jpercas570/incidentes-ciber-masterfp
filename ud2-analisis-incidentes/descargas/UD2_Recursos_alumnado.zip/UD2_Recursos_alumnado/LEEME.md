# UD2. Recursos de las prácticas

Material de las prácticas P2 a P5 de la UD2 (Análisis de incidentes de ciberseguridad, módulo 5021).
La práctica P1 se hace con las tablas del módulo 1 y no necesita ficheros.

- P2: capturas (`capturas/`), reglas de Suricata (`reglas/local.rules`) y de Wazuh (`wazuh/`).
- P3: eventos del control de accesos, `auth.log` de dos servidores, órdenes de trabajo, inventario y `correlaciona.py`.
- P4: evento de MISP, pulso de OTX y `depura_ioc.py`.
- P5: `cola_triaje.pcap`, reglas, carpeta `contexto/` y plantilla de ficha.

Requisitos: Ubuntu 26.04 con `suricata` (rama 8), `jq`, `python3`, `nftables` y `dnstwist`:

    sudo apt update && sudo apt install -y suricata jq nftables dnstwist

Todo es sintético e inofensivo: los «ejecutables» son texto y las direcciones y dominios son de documentación
(RFC 5737 y RFC 2606). Las horas están en noviembre de 2026: ejecuta Suricata con `TZ=Europe/Madrid`.
Los ficheros `sysmon_PC-ADM-07.csv` y `correo_pasarela.csv` están en UTC.
