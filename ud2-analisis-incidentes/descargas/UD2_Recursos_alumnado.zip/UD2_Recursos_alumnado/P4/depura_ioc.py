#!/usr/bin/env python3
"""Depura una lista de direcciones IP obtenidas de fuentes de inteligencia
y genera un conjunto de nftables listo para cargar en el cortafuegos."""
import ipaddress
import sys
from datetime import date

# Redes que nunca deben acabar en una lista de bloqueo
NO_BLOQUEAR = [ipaddress.ip_network(red) for red in (
    "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16",   # direccionamiento privado
    "127.0.0.0/8", "169.254.0.0/16", "224.0.0.0/4",    # bucle local, enlace local, multidifusión
    "192.0.2.0/24",                                    # rango público de la organización (ejemplo)
)]
PERMITIDAS = {ipaddress.ip_address(ip) for ip in (
    "1.1.1.1", "8.8.8.8", "9.9.9.9",                   # servidores DNS públicos de uso general
)}


def depurar(lineas):
    validas, descartadas = set(), []
    for linea in lineas:
        texto = linea.split("#")[0].strip()
        if not texto:
            continue
        try:
            ip = ipaddress.ip_address(texto)
        except ValueError:
            descartadas.append((texto, "no es una dirección IP"))
            continue
        if ip.version != 4:
            descartadas.append((texto, "no es IPv4"))
        elif ip in PERMITIDAS:
            descartadas.append((texto, "está en la lista de direcciones permitidas"))
        elif any(ip in red for red in NO_BLOQUEAR):
            descartadas.append((texto, "pertenece a una red propia o reservada"))
        else:
            validas.add(ip)
    return sorted(validas), descartadas


def main():
    if len(sys.argv) != 3:
        sys.exit("Uso: depura_ioc.py ENTRADA.txt SALIDA.nft")
    with open(sys.argv[1], encoding="utf-8") as entrada:
        validas, descartadas = depurar(entrada)
    if not validas:
        sys.exit("No queda ninguna dirección válida: no se genera el fichero.")
    elementos = ", ".join(str(ip) for ip in validas)
    with open(sys.argv[2], "w", encoding="utf-8") as salida:
        salida.write(f"""#!/usr/sbin/nft -f
# Generado por depura_ioc.py el {date.today().isoformat()}
# Cada dirección caduca sola a los 30 días si no se vuelve a cargar.
table inet filtro_ioc
delete table inet filtro_ioc

table inet filtro_ioc {{
    set ioc_ipv4 {{
        type ipv4_addr
        flags timeout
        timeout 30d
        elements = {{ {elementos} }}
    }}
    chain reenvio {{
        type filter hook forward priority filter; policy accept;
        ip daddr @ioc_ipv4 counter log prefix "IOC-BLOQUEADA " drop
        ip saddr @ioc_ipv4 counter log prefix "IOC-BLOQUEADA " drop
    }}
}}
""")
    print(f"Direcciones cargadas: {len(validas)}")
    for texto, motivo in descartadas:
        print(f"Descartada {texto}: {motivo}")


if __name__ == "__main__":
    main()
